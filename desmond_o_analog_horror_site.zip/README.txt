# DESMOND O — Analog Horror Website

This is a free static website starter designed around the Desmond O concept.

Files:
- index.html — page structure
- style.css — CRT/analog-horror visual style
- script.js — warning screen, archive files, and glitches

To publish it free with GitHub Pages:
1. Create a free GitHub account.
2. Create a new public repository.
3. Upload these three website files.
4. Open Settings → Pages.
5. Choose "Deploy from a branch", select the main branch and root folder.
6. Save. GitHub will provide the free .github.io website address.

You can replace the placeholder Desmond O artwork with your own image.
